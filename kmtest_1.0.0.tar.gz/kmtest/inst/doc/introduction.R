## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----eval=FALSE---------------------------------------------------------------
# # Install from CRAN (when available)
# install.packages("kmtest")
# 
# # Or install development version
# # devtools::install_github("merwanroudane/kmtest")

## ----load---------------------------------------------------------------------
library(kmtest)

## ----linear_sim---------------------------------------------------------------
set.seed(123)
n <- 200
mu <- 0.5
y_linear <- numeric(n)
y_linear[1] <- 100
epsilon <- rnorm(n, 0, 1)

for (t in 2:n) {
  y_linear[t] <- y_linear[t-1] + mu + epsilon[t]
}

## ----linear_plot--------------------------------------------------------------
# Save current par settings
oldpar <- par(no.readonly = TRUE)
par(mfrow = c(2, 2))

plot(y_linear, type = "l", main = "Linear Process (Level)", 
     ylab = "y", xlab = "Time")
plot(log(y_linear), type = "l", main = "Linear Process (Log)", 
     ylab = "log(y)", xlab = "Time")
plot(diff(y_linear), type = "l", main = "First Difference (Level)", 
     ylab = expression(Delta*y), xlab = "Time")
plot(diff(log(y_linear)), type = "l", main = "First Difference (Log)", 
     ylab = expression(Delta*log(y)), xlab = "Time")

# Restore par settings
par(oldpar)

## ----linear_test--------------------------------------------------------------
result_linear <- km_test_suite(y_linear, has_drift = TRUE)

## ----log_sim------------------------------------------------------------------
set.seed(456)
n <- 200
eta <- 0.002
log_y <- numeric(n)
log_y[1] <- log(100)
u <- rnorm(n, 0, 0.01)

for (t in 2:n) {
  log_y[t] <- log_y[t-1] + eta + u[t]
}

y_log <- exp(log_y)

## ----log_plot-----------------------------------------------------------------
# Save current par settings
oldpar <- par(no.readonly = TRUE)
par(mfrow = c(2, 2))

plot(y_log, type = "l", main = "Log Process (Level)", 
     ylab = "y", xlab = "Time")
plot(log(y_log), type = "l", main = "Log Process (Log)", 
     ylab = "log(y)", xlab = "Time")
plot(diff(y_log), type = "l", main = "First Difference (Level)", 
     ylab = expression(Delta*y), xlab = "Time")
plot(diff(log(y_log)), type = "l", main = "First Difference (Log)", 
     ylab = expression(Delta*log(y)), xlab = "Time")

# Restore par settings
par(oldpar)

## ----log_test-----------------------------------------------------------------
result_log <- km_test_suite(y_log, has_drift = TRUE)

## ----v1-----------------------------------------------------------------------
v1_result <- km_v1_test(y_linear)
print(v1_result)

## ----v2-----------------------------------------------------------------------
v2_result <- km_v2_test(y_log)
print(v2_result)

## ----nodrift_sim--------------------------------------------------------------
set.seed(789)
n <- 200
y_rw <- cumsum(rnorm(n)) + 100

## ----nodrift_test-------------------------------------------------------------
result_nodrift <- km_test_suite(y_rw, has_drift = FALSE)

## ----custom_lag---------------------------------------------------------------
result_custom <- km_v1_test(y_linear, p = 2)

## ----max_lag------------------------------------------------------------------
result_maxlag <- km_test_suite(y_linear, has_drift = TRUE, max_p = 8)

## ----verbose------------------------------------------------------------------
# Suppress output
result_quiet <- km_test_suite(y_linear, has_drift = TRUE, verbose = FALSE)

# The result is still returned
print(result_quiet$conclusion)

## ----citation, eval=FALSE-----------------------------------------------------
# citation("kmtest")

