library(testthat)
library(kmtest)

test_check("kmtest")
